
function fillDropDowns(){
 
//var objDropdown = document.getElementById('searchcategorydrop');
var objDropdown = document.search_formProd['searchcategorydrop'];

//var opt = document.createElement("option");
//opt.text = 'Accessory';
//opt.value = '/accessories';
//objDropdown.options[objDropdown.length] = opt;
//objDropdown.add(opt, null); // doesn't work in IE
 

objDropdown.options[objDropdown.length] =  new Option('Accessory','/accessories'); 
objDropdown.options[objDropdown.length] =  new Option('ATB Tires','/tires/TiresATB/');
objDropdown.options[objDropdown.length] =  new Option('Babyseats','/babyseatstrikes/BabySeats/');
objDropdown.options[objDropdown.length] =  new Option('Bags','/bagsracks' );
objDropdown.options[objDropdown.length] =  new Option('Bar Ends' ,'/barsstems/BarEnds/');
objDropdown.options[objDropdown.length] =  new Option('Bib Shorts' ,'/clothing/BibShorts/');
objDropdown.options[objDropdown.length] =  new Option('Bicycle Fenders' ,'/accessories/Fenders/');
objDropdown.options[objDropdown.length] =  new Option('Bicycles' ,'/bikes');
objDropdown.options[objDropdown.length] =  new Option('Bike Racks' ,'/bagsracks/Racks/');
objDropdown.options[objDropdown.length] =  new Option('BMX Accessories' ,'/accessories/BMXAccess/');
objDropdown.options[objDropdown.length] =  new Option('BMX Tires' ,'/tires/TiresBMX/');
objDropdown.options[objDropdown.length] =  new Option('BMX Wheels' ,'/wheels/WheelBMX/');
objDropdown.options[objDropdown.length] =  new Option('Body Armor' ,'/clothing/BodyPadding/');
objDropdown.options[objDropdown.length] =  new Option('Body Lotions' ,'/clothing/BodyLotions/');
objDropdown.options[objDropdown.length] =  new Option('Bottom Brackets' ,'/bikeparts/BBBrackets/');
objDropdown.options[objDropdown.length] =  new Option('Brakes' ,'/bikeparts/Brakes/');
objDropdown.options[objDropdown.length] =  new Option('Brakes-Disc' ,'/bikeparts/BrakesDisc/');
objDropdown.options[objDropdown.length] =  new Option('Car Carriers' ,'/carcarriers');
objDropdown.options[objDropdown.length] =  new Option('Cassettes' ,'/drivetrain/Cassettes/');
objDropdown.options[objDropdown.length] =  new Option('Chains' ,'/drivetrain/Chains/');
objDropdown.options[objDropdown.length] =  new Option('Clipless Pedals' ,'/pedals/PedalsRoad/');
objDropdown.options[objDropdown.length] =  new Option('Cranksets' ,'/drivetrain/Cranks/');
objDropdown.options[objDropdown.length] =  new Option('Cycle Computers' ,'/electronics/Computers/');
objDropdown.options[objDropdown.length] =  new Option('Eyewear' ,'/clothing/Eyeglasses/');
objDropdown.options[objDropdown.length] =  new Option('Front Derailleur' ,'/drivetrain/DeraillFront/');
objDropdown.options[objDropdown.length] =  new Option('Gloves' ,'/clothing/Gloves/');
objDropdown.options[objDropdown.length] =  new Option('Handlebar Tape/Grips' ,'/barsstems/BarCovering/');
objDropdown.options[objDropdown.length] =  new Option('Handlebars' ,'/barsstems');
objDropdown.options[objDropdown.length] =  new Option('Hats' ,'/clothing/Hats/');
objDropdown.options[objDropdown.length] =  new Option('Headsets' ,'/bikeparts/Headsets/');
objDropdown.options[objDropdown.length] =  new Option('Heart Rate Monitors' ,'/electronics/HeartRate/');
objDropdown.options[objDropdown.length] =  new Option('Helmets' ,'/helmets');
objDropdown.options[objDropdown.length] =  new Option('Hubs' ,'/bikeparts/Hubs/');
objDropdown.options[objDropdown.length] =  new Option('Hydration' ,'/hydration');
objDropdown.options[objDropdown.length] =  new Option('Indoor Trainers' ,'/indoortrainers');
objDropdown.options[objDropdown.length] =  new Option('Jackets' ,'/clothing/Jackets/');
objDropdown.options[objDropdown.length] =  new Option('Jerseys' ,'/clothing/Jerseys/');
objDropdown.options[objDropdown.length] =  new Option('Joggers' ,'/joggers');
objDropdown.options[objDropdown.length] =  new Option('LightSets' ,'/lights');
objDropdown.options[objDropdown.length] =  new Option('Locks' ,'/locks');
objDropdown.options[objDropdown.length] =  new Option('Lubrication' ,'/maintenance/Lubes/');
objDropdown.options[objDropdown.length] =  new Option('Mirrors' ,'/accessories/Mirrors/');
objDropdown.options[objDropdown.length] =  new Option('Miscellaneous Components' ,'/bikeparts/MiscBikeParts/');
objDropdown.options[objDropdown.length] =  new Option('Mountain Wheels' ,'/wheels/WheelMTB/');
objDropdown.options[objDropdown.length] =  new Option('Pumps' ,'/pumps');
objDropdown.options[objDropdown.length] =  new Option('Rear Derailleur' ,'/drivetrain/DeraillRear/');
objDropdown.options[objDropdown.length] =  new Option('Regular Pedals' ,'/pedals');
objDropdown.options[objDropdown.length] =  new Option('Road Groups' ,'/groupkits/RoadGroups/');
objDropdown.options[objDropdown.length] =  new Option('Road Kits' ,'/groupkits/RoadKits/');
objDropdown.options[objDropdown.length] =  new Option('Road Tires' ,'/tires/TiresRoad/');
objDropdown.options[objDropdown.length] =  new Option('Road Wheels' ,'/wheels/WheelRoad/');
objDropdown.options[objDropdown.length] =  new Option('Seatposts' ,'/bikeparts/Seatposts/');
objDropdown.options[objDropdown.length] =  new Option('Seats' ,'/seats');
objDropdown.options[objDropdown.length] =  new Option('Shifter/Levers' ,'/bikeparts/ShiftersRoad/');
objDropdown.options[objDropdown.length] =  new Option('Shock Accessories' ,'/bikeparts/ShockAccess/');
objDropdown.options[objDropdown.length] =  new Option('Shocks/Forks' ,'/bikeparts/ForksShocks/');
objDropdown.options[objDropdown.length] =  new Option('Shoes' ,'/shoes');
objDropdown.options[objDropdown.length] =  new Option('Shorts' ,'/clothing/Shorts/');
objDropdown.options[objDropdown.length] =  new Option('Socks' ,'/clothing/socks/');
objDropdown.options[objDropdown.length] =  new Option('Stems' ,'/barsstems/Stems/');
objDropdown.options[objDropdown.length] =  new Option('Storage Systems' ,'/storagesystems');
objDropdown.options[objDropdown.length] =  new Option('Tights' ,'/clothing/WinterClothing/');
objDropdown.options[objDropdown.length] =  new Option('Tire Tools' ,'/maintenance/TireTools/');
objDropdown.options[objDropdown.length] =  new Option('Tools' ,'/maintenance/');
objDropdown.options[objDropdown.length] =  new Option('Trailers', '/joggers/Trailers/');
objDropdown.options[objDropdown.length] =  new Option('Tubes' ,'/tires/Tubes/');
objDropdown.options[objDropdown.length] =  new Option('Winter Clothing Accessories' ,'/clothing/WinterClothing/');
}

fillDropDowns();